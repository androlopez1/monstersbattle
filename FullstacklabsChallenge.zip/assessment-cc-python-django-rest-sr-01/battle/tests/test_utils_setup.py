from django.test import TestCase

from utils.utils import monster_a_data, monster_b_data


class UtilsSetUp(TestCase):
    monster_A_data = monster_a_data

    monster_B_data = monster_b_data
